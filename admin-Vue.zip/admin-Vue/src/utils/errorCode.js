export default {
  401: "Authentication failed, please login again",
  403: "No permission",
  404: "Not Found",
  default: "Unknown error",
};
